package com.pubgaimai.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.content.SharedPreferences;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.*;

public class MainActivity extends Activity {
    private final int BG = Color.rgb(8, 13, 23), PANEL = Color.rgb(17, 27, 43);
    private final int CYAN = Color.rgb(86, 225, 231), WHITE = Color.rgb(237, 245, 255);
    private final int MUTED = Color.rgb(153, 171, 197);
    private LinearLayout root, valuesPanel;
    private Spinner scopeSpinner;
    private TextView coachResult, status;
    private SharedPreferences prefs;
    private String active = "Red Dot / Holo";
    private final String[] scopes = {"TPP без прицела","FPP без прицела","Red Dot / Holo","2x","3x","4x / VSS","6x","8x"};
    private final String[] paramNames = {"Camera","ADS","Gyroscope","ADS Gyroscope"};
    private final int[][] defaults = {
        {105,95,300,300},{100,90,300,300},{45,40,300,300},{35,32,280,280},
        {24,22,240,240},{18,16,200,200},{12,10,100,100},{8,7,70,70}
    };
    private final Map<String,int[]> values = new LinkedHashMap<>();
    private final Map<String,SeekBar[]> bars = new HashMap<>();
    private final Map<String,TextView[]> numbers = new HashMap<>();
    private EditText presetName;
    private Spinner symptomSpinner, strengthSpinner;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("aim_ai_local", MODE_PRIVATE);
        for (int i=0;i<scopes.length;i++) values.put(scopes[i], defaults[i].clone());
        loadValues();
        buildUi();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16),dp(20),dp(16),dp(30)); root.setBackgroundColor(BG);
        scroll.setFillViewport(true); scroll.addView(root); setContentView(scroll);

        TextView eyebrow = text("SENSITIVITY LAB  ·  ANDROID", 11, CYAN, true);
        root.addView(eyebrow);
        TextView title = text("PUBG AIM AI", 30, WHITE, true); title.setPadding(0,dp(3),0,dp(2)); root.addView(title);
        TextView subtitle = text("Персональный тренер сенсы · v1.0", 14, MUTED, false); root.addView(subtitle);
        LinearLayout chips = new LinearLayout(this); chips.setOrientation(LinearLayout.VERTICAL);
        chips.addView(text("TECNO POVA 7 Pro 5G  •  90 FPS",12,CYAN,true));
        chips.addView(text("Гироскоп: всегда  •  Управление: 4 пальца",12,MUTED,false));
        chips.setPadding(dp(12),dp(12),dp(12),dp(12)); chips.setBackground(bg(PANEL,14));
        addGap(root,14); root.addView(chips);

        addSection("01  ·  ПРОФИЛЬ ПРИЦЕЛА","Camera, ADS, Gyroscope и ADS Gyroscope");
        scopeSpinner = new Spinner(this);
        scopeSpinner.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, scopes));
        scopeSpinner.setSelection(Arrays.asList(scopes).indexOf(active));
        scopeSpinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){
            public void onNothingSelected(android.widget.AdapterView<?> p){}
            public void onItemSelected(android.widget.AdapterView<?> p, View v,int pos,long id){active=scopes[pos];renderValues();}
        });
        root.addView(scopeSpinner);
        valuesPanel = new LinearLayout(this); valuesPanel.setOrientation(LinearLayout.VERTICAL);
        addGap(root,8); root.addView(valuesPanel);
        Button reset = button("Вернуть стартовые значения", false);
        reset.setOnClickListener(v->{int idx=Arrays.asList(scopes).indexOf(active);values.put(active,defaults[idx].clone());renderValues();saveValues();});
        addGap(root,8); root.addView(reset);

        addSection("02  ·  AI FEEDBACK COACH","Отметь главный симптом после теста на полигоне.");
        symptomSpinner = spinner(new String[]{"Прицел уходит вверх","Прицел уходит вниз","Прицел трясётся","Доводка слишком медленная","Уводит влево","Уводит вправо"});
        strengthSpinner = spinner(new String[]{"Небольшая проблема","Средняя проблема","Сильная проблема"});
        root.addView(label("Что происходит?")); root.addView(symptomSpinner);
        root.addView(label("Сила проблемы")); root.addView(strengthSpinner);
        Button analyze=button("Рассчитать корректировку",true);
        analyze.setOnClickListener(v->analyze()); addGap(root,8);root.addView(analyze);
        coachResult=text("Выбери симптом и рассчитай небольшой шаг для следующего теста.",14,WHITE,false);
        coachResult.setPadding(dp(12),dp(12),dp(12),dp(12));coachResult.setBackground(bg(Color.rgb(14,39,48),12));
        addGap(root,8);root.addView(coachResult);

        addSection("03  ·  СОХРАНЁННЫЕ ПРЕСЕТЫ","Хранятся локально на этом устройстве.");
        presetName = new EditText(this);presetName.setSingleLine(true);presetName.setHint("Название пресета, например TDM V1");
        presetName.setHintTextColor(MUTED);presetName.setTextColor(WHITE);presetName.setBackground(bg(PANEL,10));
        root.addView(presetName);
        Button save=button("Сохранить текущие значения",true);save.setOnClickListener(v->savePreset());addGap(root,8);root.addView(save);
        Button load=button("Показать сохранённые пресеты",false);load.setOnClickListener(v->showPresets());addGap(root,8);root.addView(load);
        status=text("",12,CYAN,false);addGap(root,5);root.addView(status);

        addSection("КАК ПОЛЬЗОВАТЬСЯ","1. Проведи одинаковый короткий тест в тренировочном режиме.\n2. Отметь симптом в AI Feedback Coach.\n3. Вручную перенеси предложенное значение в PUBG.\n4. Повтори тест и сохрани удачный пресет.");
        TextView disclaimer=text("Важно: приложение не подключается к PUBG, не меняет игровые файлы и не является аимботом. Рекомендации основаны только на твоём выборе симптома; это не автоматическое считывание игрового процесса.",12,MUTED,false);
        disclaimer.setPadding(0,dp(8),0,0);root.addView(disclaimer);
        renderValues();
    }

    private void addSection(String heading,String desc){
        addGap(root,20);TextView h=text(heading,17,CYAN,true);root.addView(h);
        TextView d=text(desc,12,MUTED,false);d.setPadding(0,dp(3),0,dp(9));root.addView(d);
    }
    private void renderValues(){
        if(valuesPanel==null)return;
        valuesPanel.removeAllViews();
        int[] vals=values.get(active);
        SeekBar[] sb=new SeekBar[4];TextView[] tv=new TextView[4];
        for(int i=0;i<4;i++){
            final int j=i;
            LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.VERTICAL);row.setPadding(dp(10),dp(7),dp(10),dp(7));row.setBackground(bg(PANEL,12));
            LinearLayout head=new LinearLayout(this);head.setGravity(Gravity.CENTER_VERTICAL);
            TextView name=text(paramNames[i],14,WHITE,true);head.addView(name,new LinearLayout.LayoutParams(0,-2,1));
            tv[i]=text(String.valueOf(vals[i]),14,CYAN,true);head.addView(tv[i]);row.addView(head);
            sb[i]=new SeekBar(this);sb[i].setMax(i<2?199:399);sb[i].setProgress(Math.max(0,Math.min(sb[i].getMax(),vals[i]-1)));
            sb[i].setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
                public void onProgressChanged(SeekBar s,int progress,boolean user){int n=progress+1;values.get(active)[j]=n;tv[j].setText(String.valueOf(n));if(user)saveValues();}
                public void onStartTrackingTouch(SeekBar s){} public void onStopTrackingTouch(SeekBar s){}
            });
            row.addView(sb[i]);addGap(valuesPanel,7);valuesPanel.addView(row);
        }
        bars.put(active,sb);numbers.put(active,tv);
    }
    private void analyze(){
        int symptom=symptomSpinner.getSelectedItemPosition(), strength=strengthSpinner.getSelectedItemPosition()+1;
        int[] v=values.get(active);String msg;
        if(symptom==0){v[3]=clamp(v[3]+4*strength,1,400);msg="ADS Gyroscope повышен на "+(4*strength)+" пунктов для проверки контроля подъёма.";}
        else if(symptom==1){v[3]=clamp(v[3]-4*strength,1,400);msg="ADS Gyroscope снижен на "+(4*strength)+" пунктов для проверки обратной реакции.";}
        else if(symptom==2){v[3]=clamp(v[3]-5*strength,1,400);v[2]=clamp(v[2]-3*strength,1,400);msg="Gyroscope и ADS Gyroscope немного снижены для проверки дрожания.";}
        else if(symptom==3){v[0]=clamp(v[0]+3*strength,1,200);v[2]=clamp(v[2]+4*strength,1,400);msg="Camera и Gyroscope немного повышены для более быстрой доводки.";}
        else {v[3]=clamp(v[3]+2*strength,1,400);msg="Сделан небольшой пробный шаг Gyroscope. Проверь ведение пальца и наклон устройства: боковой увод не всегда исправляется сенсой.";}
        renderValues();saveValues();coachResult.setText("РЕКОМЕНДАЦИЯ · "+active+"\n\n"+msg+"\n\nПеренеси значения вручную в PUBG и повтори тот же тест. Меняй по одному параметру за раз; если стало хуже — верни предыдущие значения.");
    }
    private void savePreset(){
        String name=presetName.getText().toString().trim();if(name.isEmpty())name="TDM preset "+(System.currentTimeMillis()%10000);
        try{
            JSONArray arr=new JSONArray(prefs.getString("presets","[]"));
            JSONObject obj=new JSONObject();obj.put("name",name);obj.put("active",active);obj.put("date",new java.text.SimpleDateFormat("dd.MM.yyyy",Locale.getDefault()).format(new Date()));
            JSONObject all=new JSONObject();for(String s:scopes){JSONArray a=new JSONArray();for(int n:values.get(s))a.put(n);all.put(s,a);}obj.put("values",all);
            arr.put(obj);prefs.edit().putString("presets",arr.toString()).apply();status.setText("Сохранено: "+name);presetName.setText("");
        }catch(Exception e){status.setText("Не удалось сохранить пресет.");}
    }
    private void showPresets(){
        try{
            JSONArray arr=new JSONArray(prefs.getString("presets","[]"));
            if(arr.length()==0){status.setText("Пока нет сохранённых пресетов.");return;}
            String[] names=new String[arr.length()];for(int i=0;i<arr.length();i++)names[i]=arr.getJSONObject(i).optString("name","Пресет "+(i+1));
            new android.app.AlertDialog.Builder(this).setTitle("Выбери пресет").setItems(names,(d,which)->{
                try{JSONObject o=arr.getJSONObject(which),all=o.getJSONObject("values");for(String s:scopes){JSONArray a=all.optJSONArray(s);if(a!=null&&a.length()==4){int[] n=new int[4];for(int i=0;i<4;i++)n[i]=a.optInt(i,defaults[0][i]);values.put(s,n);}}
                    active=o.optString("active","Red Dot / Holo");int idx=Arrays.asList(scopes).indexOf(active);if(idx<0)idx=2;scopeSpinner.setSelection(idx);renderValues();saveValues();status.setText("Загружен: "+names[which]);
                }catch(Exception e){status.setText("Ошибка загрузки пресета.");}
            }).setNegativeButton("Отмена",null).show();
        }catch(Exception e){status.setText("Не удалось прочитать пресеты.");}
    }
    private void loadValues(){
        try{JSONObject all=new JSONObject(prefs.getString("values","{}"));for(String s:scopes){JSONArray a=all.optJSONArray(s);if(a!=null&&a.length()==4){int[] v=new int[4];for(int i=0;i<4;i++)v[i]=a.optInt(i,defaults[0][i]);values.put(s,v);}}}catch(Exception ignored){}
    }
    private void saveValues(){
        try{JSONObject all=new JSONObject();for(String s:scopes){JSONArray a=new JSONArray();for(int n:values.get(s))a.put(n);all.put(s,a);}prefs.edit().putString("values",all.toString()).apply();}catch(Exception ignored){}
    }
    private int clamp(int n,int min,int max){return Math.max(min,Math.min(max,n));}
    private Spinner spinner(String[] entries){Spinner s=new Spinner(this);s.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,entries));return s;}
    private TextView label(String s){TextView t=text(s,12,MUTED,true);t.setPadding(0,dp(8),0,dp(4));return t;}
    private Button button(String s,boolean primary){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextColor(primary?Color.rgb(5,17,27):WHITE);b.setTypeface(null,Typeface.BOLD);b.setBackground(bg(primary?CYAN:Color.rgb(29,43,64),12));return b;}
    private TextView text(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(null,Typeface.BOLD);return t;}
    private GradientDrawable bg(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));d.setStroke(dp(1),Color.rgb(39,56,79));return d;}
    private void addGap(LinearLayout parent,int h){View v=new View(this);parent.addView(v,new LinearLayout.LayoutParams(1,dp(h)));}
    private int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+0.5f);}
}
