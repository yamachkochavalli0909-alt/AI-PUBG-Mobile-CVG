# PUBG AIM AI — Android source project

Native Android app prototype (Java, no third-party runtime dependencies) for sensitivity tuning.

## Included
- Native Android interface with cyber-blue theme.
- Separate Camera, ADS, Gyroscope and ADS Gyroscope sliders for 8 scope profiles.
- Feedback-based suggestions for common training-range symptoms.
- Local saving/loading of presets via Android SharedPreferences.
- No network permissions, no game file access, no cheats, no automation.

## Build APK
Requirements: Android Studio (recommended) and Android SDK Platform 35; JDK 17.

1. Open this folder in Android Studio.
2. Let Gradle sync and install any requested Android SDK components.
3. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Debug APK is typically created at `app/build/outputs/apk/debug/app-debug.apk`.

Command line (after installing Gradle / Android SDK):
`gradle assembleDebug`

## Notes
- This is a source project, not a precompiled APK.
- AI recommendations are deterministic, feedback-based heuristics; they do not read gameplay automatically.
- Starter sensitivity values are test baselines, not guaranteed optimal settings.
