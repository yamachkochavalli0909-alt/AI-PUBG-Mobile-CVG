package com.svjgojo.aipubgcvg;

import android.app.Activity;
import android.os.Bundle;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.util.Locale;

public class MainActivity extends Activity {
    private final int BG = Color.rgb(6,17,31), PANEL = Color.rgb(12,31,51), CYAN = Color.rgb(40,199,255), WHITE = Color.rgb(232,245,255), MUTED = Color.rgb(145,174,197);
    private SharedPreferences prefs;
    private SeekBar[] bars = new SeekBar[4];
    private TextView[] values = new TextView[4];
    private TextView advice;
    private Spinner opticSpinner, issueSpinner, weaponSpinner;
    private final String[] labels = {"CAMERA", "ADS", "GYROSCOPE", "ADS GYROSCOPE"};
    private final int[] defaults = {25, 20, 280, 300};

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("cvg_presets", MODE_PRIVATE);
        buildUI();
        loadPreset();
    }

    private GradientDrawable shape(int color, int stroke) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(16));
        if (stroke != 0) d.setStroke(dp(1), stroke); return d;
    }
    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + .5f); }
    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD); return t;
    }
    private LinearLayout column() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }
    private void pad(View v, int a, int b, int c, int d) { v.setPadding(dp(a),dp(b),dp(c),dp(d)); }
    private void buildUI() {
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true); scroll.setBackgroundColor(BG);
        LinearLayout root = column(); pad(root,18,18,18,28); root.setBackgroundColor(BG); scroll.addView(root);
        TextView eyebrow = text("SVJ GOJO  /  PERSONAL GAMING TOOL", 11, CYAN, true); eyebrow.setLetterSpacing(.08f); root.addView(eyebrow);
        TextView title = text("AI PUBG MOBILE\nCVG", 30, WHITE, true); title.setLineSpacing(0,1.02f); LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(-1,-2); tp.topMargin=dp(8); root.addView(title,tp);
        TextView sub = text("SENSITIVITY LAB  •  CYBER BLUE", 12, MUTED, true); LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1,-2); sp.topMargin=dp(8); root.addView(sub,sp);
        LinearLayout status = column(); status.setBackground(shape(PANEL,CYAN)); pad(status,15,14,15,14); LinearLayout.LayoutParams stp = new LinearLayout.LayoutParams(-1,-2); stp.topMargin=dp(20); root.addView(status,stp);
        status.addView(text("DEVICE PROFILE",11,CYAN,true)); status.addView(text("TECNO POVA 7 Pro 5G  •  90 FPS",15,WHITE,true)); status.addView(text("4 fingers  |  Gyroscope always on",12,MUTED,false));
        addSection(root,"01  /  PROFILE");
        opticSpinner = spinner(new String[]{"Red Dot / Holo", "2x Scope", "3x Scope", "4x Scope", "6x Scope", "8x Scope"}); addLabeled(root,"Active optic",opticSpinner);
        weaponSpinner = spinner(new String[]{"All-round (recommended)","M416 — spray control","AKM — close range","UMP45 — TDM","MG3 — sustained fire"}); addLabeled(root,"Weapon / play style",weaponSpinner);
        addSection(root,"02  /  SENSITIVITY CONTROLS");
        for (int i=0;i<4;i++) addSensitivity(root,i);
        TextView note = text("Camera and ADS use a 0–100 scale. Gyroscope uses a 0–400 scale. These are editable starting values, not guaranteed pro settings.",11,MUTED,false); pad(note,2,8,2,8); root.addView(note);
        addSection(root,"03  /  AI COACH");
        issueSpinner = spinner(new String[]{"Spray climbs upward", "Aim shakes while spraying", "Close-range tracking is slow", "Overshooting the target", "Need a balanced setup"}); addLabeled(root,"What feels wrong?",issueSpinner);
        Button coach = button("GENERATE ADJUSTMENT TIPS"); LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1,dp(50)); cp.topMargin=dp(10); root.addView(coach,cp);
        advice = text("Choose a problem, then tap the coach button. The coach works offline using rule-based tips.",13,WHITE,false); pad(advice,14,14,14,14); advice.setBackground(shape(PANEL,0)); LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(-1,-2); ap.topMargin=dp(10); root.addView(advice,ap);
        coach.setOnClickListener(v -> coach());
        addSection(root,"04  /  YOUR PRESET");
        LinearLayout row = new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL); row.setGravity(Gravity.CENTER_VERTICAL);
        Button save=button("SAVE PRESET"), reset=button("RESET"); LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(0,dp(48),1); bp.rightMargin=dp(6); row.addView(save,bp); LinearLayout.LayoutParams bp2=new LinearLayout.LayoutParams(0,dp(48),1); bp2.leftMargin=dp(6); row.addView(reset,bp2); root.addView(row);
        Button export=button("SHOW CONFIG TEXT"); LinearLayout.LayoutParams ep=new LinearLayout.LayoutParams(-1,dp(48)); ep.topMargin=dp(9); root.addView(export,ep);
        TextView footer=text("DEVELOPER: svj gojo  •  VERSION 1.0\nThis app does not modify PUBG files or inject into the game.",10,MUTED,false); pad(footer,4,22,4,0); root.addView(footer);
        save.setOnClickListener(v->{savePreset(); Toast.makeText(this,"Preset saved on this phone",Toast.LENGTH_SHORT).show();});
        reset.setOnClickListener(v->{for(int i=0;i<4;i++) bars[i].setProgress(defaults[i]); Toast.makeText(this,"Default starter values restored",Toast.LENGTH_SHORT).show();});
        export.setOnClickListener(v->{String cfg=configText(); new android.app.AlertDialog.Builder(this).setTitle("Your CVG configuration").setMessage(cfg).setPositiveButton("Copy",(d,w)->{android.content.ClipboardManager cm=(android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE); cm.setPrimaryClip(android.content.ClipData.newPlainText("CVG settings",cfg)); Toast.makeText(this,"Copied",Toast.LENGTH_SHORT).show();}).setNegativeButton("Close",null).show();});
        setContentView(scroll);
    }
    private Spinner spinner(String[] items) { Spinner s=new Spinner(this); ArrayAdapter<String> a=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,items); a.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item); s.setAdapter(a); s.setBackground(shape(PANEL,CYAN)); pad(s,8,2,8,2); return s; }
    private void addLabeled(LinearLayout root,String label,Spinner s){ TextView t=text(label,12,MUTED,true); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.topMargin=dp(10); root.addView(t,p); LinearLayout.LayoutParams q=new LinearLayout.LayoutParams(-1,dp(48)); q.topMargin=dp(5); root.addView(s,q); }
    private void addSection(LinearLayout root,String s){ TextView t=text(s,13,CYAN,true); t.setLetterSpacing(.05f); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.topMargin=dp(24); p.bottomMargin=dp(9); root.addView(t,p); }
    private void addSensitivity(LinearLayout root,int i){
        LinearLayout card=column(); card.setBackground(shape(PANEL,0)); pad(card,14,10,14,10); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.topMargin=dp(7); root.addView(card,p);
        LinearLayout head=new LinearLayout(this); head.setGravity(Gravity.CENTER_VERTICAL); head.setOrientation(LinearLayout.HORIZONTAL); head.addView(text(labels[i],12,WHITE,true),new LinearLayout.LayoutParams(0,-2,1)); values[i]=text("",14,CYAN,true); head.addView(values[i]); card.addView(head);
        TextView desc=text(i<2?"Finger swipe sensitivity":"Motion sensitivity",10,MUTED,false); card.addView(desc);
        bars[i]=new SeekBar(this); bars[i].setMax(i<2?100:400); bars[i].setProgress(defaults[i]); bars[i].setProgressTintList(android.content.res.ColorStateList.valueOf(CYAN)); bars[i].setThumbTintList(android.content.res.ColorStateList.valueOf(CYAN)); card.addView(bars[i]);
        bars[i].setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar b,int val,boolean user){values[i].setText(String.valueOf(val));} public void onStartTrackingTouch(SeekBar b){} public void onStopTrackingTouch(SeekBar b){}});
    }
    private Button button(String s){ Button b=new Button(this); b.setText(s); b.setTextSize(12); b.setTextColor(WHITE); b.setTypeface(Typeface.DEFAULT,Typeface.BOLD); b.setAllCaps(false); b.setBackground(shape(Color.rgb(10,57,83),CYAN)); return b; }
    private void coach(){ String issue=String.valueOf(issueSpinner.getSelectedItem()); String msg;
        if(issue.startsWith("Spray climbs")){msg="AI COACH • RECOIL GOES UP\n1. Increase ADS Gyroscope for your active optic by a small step (+10 to +20).\n2. Test a 10–15 bullet M416 spray at a fixed wall distance.\n3. Change only one value per test. If gyro is already high, check your pull-down movement and weapon attachments.";}
        else if(issue.startsWith("Aim shakes")){msg="AI COACH • SHAKE\n1. Reduce the active optic's Gyroscope by 10–20.\n2. Test while standing still, then while moving.\n3. If shake only happens with finger drag, lower ADS slightly instead.";}
        else if(issue.startsWith("Close-range")){msg="AI COACH • CLOSE RANGE\n1. Raise Camera Red Dot by 3–5 points for faster tracking.\n2. Keep gyro enabled and test hip-fire separately from ADS.\n3. Practice short tracking drills before changing more values.";}
        else if(issue.startsWith("Overshooting")){msg="AI COACH • OVERSHOOTING\n1. Lower Camera sensitivity for the selected optic by 3–5 points.\n2. Keep ADS unchanged during the first test.\n3. Repeat 5 target switches and adjust in small increments.";}
        else {msg="AI COACH • BALANCED START\n1. Keep Camera low-to-moderate and gyro higher if you aim mainly by tilting.\n2. Test Red Dot, 3x and 4x separately.\n3. Save a preset before each change so you can compare comfortably.";}
        advice.setText(msg+"\n\nThese are suggestions only; no automatic in-game changes are made.");
    }
    private String configText(){StringBuilder b=new StringBuilder("AI PUBG MOBILE CVG\nDeveloper: svj gojo\nOptic: ").append(opticSpinner.getSelectedItem()).append("\nWeapon: ").append(weaponSpinner.getSelectedItem()).append("\n"); for(int i=0;i<4;i++)b.append(labels[i]).append(": ").append(bars[i].getProgress()).append("\n"); return b.toString();}
    private void savePreset(){SharedPreferences.Editor e=prefs.edit(); for(int i=0;i<4;i++)e.putInt("v"+i,bars[i].getProgress()); e.putInt("optic",opticSpinner.getSelectedItemPosition()).putInt("weapon",weaponSpinner.getSelectedItemPosition()).apply();}
    private void loadPreset(){for(int i=0;i<4;i++){bars[i].setProgress(prefs.getInt("v"+i,defaults[i]));} opticSpinner.setSelection(prefs.getInt("optic",0)); weaponSpinner.setSelection(prefs.getInt("weapon",0));}
}
